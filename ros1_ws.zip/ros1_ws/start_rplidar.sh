source devel/setup.bash
roslaunch rplidar_ros rplidar.launch 
