source devel/setup.bash
roslaunch hector_slam_launch tutorial.launch  

