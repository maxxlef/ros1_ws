#!/usr/bin/env python

import rospy
from ros_maestro.msg import PwmCmd
from std_msgs.msg import String
import threading

# Define PWM values for different directions
COMMANDS = {
    "forward": {"left_motor": -1.0, "right_motor": -1.0},
    "backward": {"left_motor": 1.0, "right_motor": 1.0},
    "turn_left": {"left_motor": 0.5, "right_motor": -1.0},
    "turn_right": {"left_motor": -1.0, "right_motor": 0.5},
    "stop": {"left_motor": 0.0, "right_motor": 0.0}
}

# Publisher for PWM commands
pwm_pub = None

def execute_command(direction, duration):
    """
    Executes a motor command for a specified duration.
    """
    if direction in COMMANDS:
        # Get motor values for the direction
        motor_values = COMMANDS[direction]
        rospy.loginfo("Executing direction: {} for {} seconds".format(direction, duration))


        # Publish the motor commands
        pwm_pub.publish(PwmCmd(pin=1, command=motor_values["left_motor"]))  # Left motor
        pwm_pub.publish(PwmCmd(pin=0, command=motor_values["right_motor"]))  # Right motor

        # Wait for the duration
        rospy.sleep(duration)

        # Stop the motors after the duration
        rospy.loginfo("Stopping motors after duration")
        pwm_pub.publish(PwmCmd(pin=1, command=0.0))  # Left motor
        pwm_pub.publish(PwmCmd(pin=0, command=0.0))  # Right motor
    else:
        rospy.logwarn("Unknown direction: {}. Ignoring.".format(direction))

def command_callback(data):
    """
    Callback function to handle incoming commands.
    The command format is expected to be "direction:duration" (e.g., "forward:5").
    """
    try:
        # Parse the command into direction and duration
        command = data.data.strip().lower()
        direction, duration = command.split(":")
        duration = float(duration)

        # Run the command execution in a separate thread
        threading.Thread(target=execute_command, args=(direction, duration)).start()
    except ValueError:
        rospy.logerr("Invalid command format. Use 'direction:duration', e.g., 'forward:5'.")

def motor_controller():
    """
    Main function to initialize the node and set up the subscriber and publisher.
    """
    global pwm_pub

    rospy.init_node('motor_controller', anonymous=True)

    # Initialize publisher for PWM commands
    pwm_pub = rospy.Publisher('/cmd_pwm', PwmCmd, queue_size=10)

    # Initialize subscriber for motor commands
    rospy.Subscriber('/motor_command', String, command_callback)

    rospy.loginfo("Motor controller node started. Listening for commands...")
    rospy.spin()  # Keep the node running

if __name__ == "__main__":
    try:
        motor_controller()
    except rospy.ROSInterruptException:
        rospy.loginfo("Motor controller node terminated.")

