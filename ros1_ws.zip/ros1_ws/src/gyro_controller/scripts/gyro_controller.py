#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
from std_msgs.msg import String  # On publiera des messages simples
import serial
import time

def lire_et_publier_donnees_gyro(port, baudrate=57600):
    try:
        # Initialiser la connexion au port série
        with serial.Serial(port, baudrate, timeout=1) as ser:
            rospy.loginfo("Connexion etablie sur {} a {} bauds".format(port, baudrate))
            time.sleep(2)  # Attendre que le capteur soit prêt

            # Commande pour initialiser le capteur (si nécessaire)
            ser.write(b'GYRO_START\n')

            # Initialiser ROS
            rospy.init_node('gyro_publisher', anonymous=True)
            pub = rospy.Publisher('/gyro_data', String, queue_size=10)
            rate = rospy.Rate(10)  # Fréquence : 10 Hz

            while not rospy.is_shutdown():
                # Lire les données du gyroscope
                ligne = ser.readline().decode('utf-8').strip()
                if ligne:
                    # Publier les données sur le topic
                    rospy.loginfo("Donnees recues : {}".format(ligne))
                    pub.publish(ligne)
                rate.sleep()

    except serial.SerialException as e:
        rospy.logerr("Erreur de connexion au port serie : {}".format(e))
    except rospy.ROSInterruptException:
        rospy.loginfo("Arret du programme ROS.")
    finally:
        rospy.loginfo("Connexion terminee.")

if __name__ == "__main__":
    # Modifier le port selon votre configuration
    lire_et_publier_donnees_gyro(port='/dev/ttyUSB1')

