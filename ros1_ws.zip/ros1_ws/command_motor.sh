#!/bin/bash

# Publier un message toutes les 0.1 seconde (10Hz) pendant 10 secondes
echo "début"

#moteur gauche
rostopic pub /cmd_pwm ros_maestro/PwmCmd "{pin: 1, command: -1.0}" &
#moteur droit
rostopic pub /cmd_pwm ros_maestro/PwmCmd "{pin: 0, command: -1.0}" &

echo "commande terminée"
sleep 3
rostopic pub /cmd_pwm ros_maestro/PwmCmd "{pin: 1, command: 0.0}" &
rostopic pub /cmd_pwm ros_maestro/PwmCmd "{pin: 0, command: 0.0}" &

sleep 5

echo "Le script a terminé."

